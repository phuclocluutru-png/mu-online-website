<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html><head>

  
  <meta charset="utf-8">

  
  <meta http-equiv="X-UA-Compatible" content="IE=edge"><title></title>
  

  
  
  <link rel="stylesheet" href="css/style.css">

  
  <link rel="stylesheet" href="css/style2.css">

  
  <script type="text/javascript">
  </script></head><body>
<div class="video"> <video width="1070" height="600" playsinline="" autoplay="" loop="" muted =''> <source src="assets/image/bg.mp4" type="video/mp4"> </source>
</video></div>

<div class="launcher">
<div class="left">
<div class="logomuhn">
</div>

<ul class="list-btn">
  <li><a href="http://id.mu-hanoimoi.vn" target="_blank">Trang Chủ</a></li>
  <li><a href="http://id.mu-hanoimoi.vn" target="_blank">Đăng Ký</a></li>
  <li><a href="https://www.facebook.com/" target="_blank">Fanpage</a></li>
  <li><a href="https://www.facebook.com/" target="_blank">Group</a></li>
</ul>
</div>
<br>
</div>

</body></html>